import os

print("🚀 CIFAR-10 CNN Project")
print("1. Train the model")
print("2. Predict using saved model")

choice = input("Enter choice (1/2): ")

if choice == "1":
    os.system("python train.py")
elif choice == "2":
    os.system("python predict.py")
else:
    print("❌ Invalid choice")
