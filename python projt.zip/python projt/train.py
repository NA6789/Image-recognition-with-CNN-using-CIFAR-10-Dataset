import tensorflow as tf
import matplotlib.pyplot as plt
from model import build_cnn

# Loading dataset
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
x_train, x_test = x_train / 255.0, x_test / 255.0

# Building model
model = build_cnn()

# Training model
history = model.fit(x_train, y_train, epochs=10, validation_data=(x_test, y_test))

# Save the model
model.save("saved_model/cifar10_cnn.h5")
print("✅ Model saved at saved_model/cifar10_cnn.h5")

# Ploting training history
plt.plot(history.history['accuracy'], label='train_accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.savefig("training_history.png")
plt.show()
