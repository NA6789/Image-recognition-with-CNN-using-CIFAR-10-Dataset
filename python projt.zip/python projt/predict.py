import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# CIFAR-10 datasets class name
class_names = ['airplane','automobile','bird','cat','deer',
               'dog','frog','horse','ship','truck']

# Loading model
model = tf.keras.models.load_model("saved_model/cifar10_cnn.h5")

# Loading test data
(_, _), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
x_test = x_test / 255.0

# Predictions
probability_model = tf.keras.Sequential([model, tf.keras.layers.Softmax()])
predictions = probability_model.predict(x_test)

# Show 5 sample predictions
for i in range(5):
    plt.imshow(x_test[i])
    plt.title(f"Pred: {class_names[np.argmax(predictions[i])]} | Actual: {class_names[int(y_test[i])]}")
    plt.show()
